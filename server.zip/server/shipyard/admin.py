from django.contrib import admin

from shipyard.models import *

admin.site.register(Shipment)
admin.site.register(Product)
admin.site.register(Recipt)
