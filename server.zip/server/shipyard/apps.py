from django.apps import AppConfig


class ShipyardConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "shipyard"
